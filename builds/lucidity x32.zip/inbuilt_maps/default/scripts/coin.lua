local t = SFX:addTrack("coin.ogg")
_G.pickCoin = function(self)
	t:setPos(self.x,self.y)
	t:once()
	self:remove()
end 